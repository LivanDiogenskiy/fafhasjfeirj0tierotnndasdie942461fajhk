from django.db import models
from django.contrib.auth.models import User
from django_jsonform.models.fields import JSONField

PRODUCTS_SCHEMA = {
    "type": "array",
    "title": "Список покупок",
    "items": {
        "type": "object",
        "keys": {
            "product_name": {
                "type": "string",
                "title": "Название товара"
            },
            "quantity": {
                "type": "integer",
                "title": "Количество"
            },
            "meta_data": {
                "type": "array",
                "title": "Мета данные",
                "items": {
                    "type": "object",
                    "keys": {
                        "key_meta_data": {
                            "type": "string",
                            "title": "Название свойства"
                        },
                        "val_meta_data": {
                            "type": "string",
                            "title": "Значение свойства"
                        },
                    },
                },
                "minItems": 0,
                "maxItems": 100
            },
        },
    },
    "minItems": 1,
    "maxItems": 100
}

STATUS_SCHEMA = [
    ("pending", "В ожидании платежа"),
    ("failed", "Неуспешно"),
    ("processing", "В обработке"),
    ("completed", "Выполнено"),
    ("on-hold", "В ожидании"),
    ("cancelled", "Отменено"),
    ("refunded", "Возмещено")
]


class Site(models.Model):
    domain = models.CharField(max_length=150, unique=True, verbose_name="Домен")
    user = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True, verbose_name="Ответственный менеджер")
    last_update = models.DateTimeField(blank=True, null=True, verbose_name="Дата обновления")
    consumer_key = models.CharField(max_length=150, blank=True, null=True, verbose_name="Ключ пользователя WC")
    consumer_secret = models.CharField(max_length=150, blank=True, null=True, verbose_name="Секретный ключ пользователя WC")
    
    def __str__(self):
            return self.domain

    class Meta:
        verbose_name = "Сайт"
        verbose_name_plural = "Сайты"


class Order(models.Model):
    site = models.ForeignKey(Site, on_delete=models.CASCADE, verbose_name="Сайт")
    status = models.CharField(max_length=50, choices=STATUS_SCHEMA, verbose_name="Статус")
    woocommerce_id = models.CharField(max_length=250, blank=True, null=True, verbose_name="Woocommerce ID")
    date_created = models.DateTimeField(verbose_name="Дата создания заказа")
    name = models.CharField(max_length=150, verbose_name="ФИО")
    phone = models.CharField(max_length=20, verbose_name="Телефон")
    email = models.EmailField(blank=True, null=True, verbose_name="Email")
    address = models.CharField(max_length=150, blank=True, null=True, verbose_name="Адрес")
    comment = models.TextField(blank=True, null=True, verbose_name="Комментарий")
    products = JSONField(schema=PRODUCTS_SCHEMA, verbose_name="Товары")
    total = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Сумма")

    def __str__(self):
        verbose_status = ""
        for item in STATUS_SCHEMA:
            if item[0] == self.status:
                verbose_status = item[1]
        return f"{self.name} \n ({verbose_status})"

    class Meta:
        verbose_name = "Заказ"
        verbose_name_plural = "Заказы"



