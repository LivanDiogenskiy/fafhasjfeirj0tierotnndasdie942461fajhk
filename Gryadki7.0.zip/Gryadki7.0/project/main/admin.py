from django.contrib import admin
from .models import  Site, Order
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import Group


class OrderAdmin(admin.ModelAdmin):
    readonly_fields = ('woocommerce_id',)
    list_display = ('name', 'status', 'total', 'site', 'date_created')
    ordering = ('-date_created',)
    list_editable = ['status']
    
    def get_list_filter(self, request):
        if request.user.is_superuser:
            return ('site', 'status')
        return ('status',)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if not request.user.is_superuser:
            qs = qs.filter(site__user=request.user)
        return qs


class CustomUserAdmin(UserAdmin):
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Персональная информация', {'fields': ('first_name', 'last_name', 'email')}),
        ('Права доступа', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
    )
    list_display = ('username', 'email', 'get_domain')

    def get_domain(self, obj):
        try:
            site = Site.objects.get(user=obj)
            return site.domain
        except Site.DoesNotExist:
            return None

    get_domain.short_description = 'Сайт'

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(is_superuser=False)

admin.site.unregister(Group)
admin.site.unregister(User)
admin.site.register(Site)
admin.site.register(Order, OrderAdmin)
admin.site.register(User, CustomUserAdmin)




    
