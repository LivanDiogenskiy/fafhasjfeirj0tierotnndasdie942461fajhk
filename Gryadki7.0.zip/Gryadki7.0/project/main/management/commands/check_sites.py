import json
import pytz
from woocommerce import API
from datetime import datetime
from main.models import Order, Site
from django.core.management import BaseCommand

def get_woocommerce_response(domain, consumer_key, consumer_secret):
    try:
        wcapi = API(
            url=domain,
            consumer_key=consumer_key,
            consumer_secret=consumer_secret,
            timeout=50
        )
        response = wcapi.get('orders')
        return response

    except Exception as e:
        return None

def create_order_from_json(site, json_order):
    woocommerce_id = json_order['id']
    status = json_order['status']

    moscow_tz = pytz.timezone('Europe/Moscow')
    date_created = datetime.strptime(json_order["date_created"], '%Y-%m-%dT%H:%M:%S').astimezone(moscow_tz)

    pre_name = json_order['billing']['first_name'] + ' ' + json_order['billing']['last_name']
    if not pre_name:
        try:
                pre_name = json_order["meta_data"][0]["value"]
        except:
            pass
    name = pre_name
    
    phone = json_order['billing']['phone']
    email = json_order['billing']['email']

    address = json_order['billing']['address_1'] + json_order['billing']['city']
    comment = json_order['customer_note']

    products = [
        {
            "product_name": product_item["name"],
            "quantity": product_item["quantity"],
            "meta_data": [
                {
                    "key_meta_data": meta_item["display_key"],
                    "val_meta_data": meta_item["display_value"]
                } for meta_item in product_item["meta_data"] 
            ]
        } for product_item in json_order["line_items"] 
    ]

    total = json_order['total']

    order = Order(
        site=site,
        status=status,
        woocommerce_id=woocommerce_id,
        date_created=date_created,
        name=name,
        phone=phone,
        email=email,
        address=address,
        comment=comment,
        products=products,
        total=total
    )

    order.save()

class Command(BaseCommand):
    help = "Send Today's Orders Report to Admins"
    def handle(self, *args, **options):
        sites = Site.objects.all()
        for site in sites:
            response = get_woocommerce_response(
                site.domain, 
                site.consumer_key, 
                site.consumer_secret
            )
            if not response:
                continue

            for json_order in response.json():
                moscow_tz = pytz.timezone('Europe/Moscow')
                order_date_created = datetime.strptime(json_order["date_created"], '%Y-%m-%dT%H:%M:%S').astimezone(moscow_tz)
                if site.last_update < order_date_created:
                    create_order_from_json(site, json_order)
            
            utc_now = datetime.utcnow()
            moscow_now = utc_now.replace(tzinfo=pytz.UTC).astimezone(moscow_tz)
            site.last_update = moscow_now
            site.save()