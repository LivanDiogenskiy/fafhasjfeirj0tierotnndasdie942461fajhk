#!/bin/sh

# python manage.py flush --no-input

python manage.py makemigrations
python manage.py migrate
python manage.py init_database

DJANGO_SUPERUSER_USERNAME=admin \
DJANGO_SUPERUSER_PASSWORD=HaJroOeXdq24 \
DJANGO_SUPERUSER_EMAIL="admin@admin.com" \
python manage.py createsuperuser --noinput


exec "$@"
