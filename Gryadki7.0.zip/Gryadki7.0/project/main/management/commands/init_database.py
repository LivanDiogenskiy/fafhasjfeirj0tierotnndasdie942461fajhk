from datetime import datetime
from main.models import Site
from django.contrib.auth.models import User
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = 'My custom command'

    def handle(self, *args, **options):


        my_users = [
            {
                "username": "beds_to_dacha_manager",
                "password": "bTOZa3BmPkUm1Ep",
            },
            {
                "username": "beds_by_mail_manager",
                "password": "w9UQ2s37u0Z4aaG",
            },
            {
                "username": "borisovka35_manager",
                "password": "rTdXp7H4wBTDKyH",
            },
            {
                "username": "blok_konteiner35_manager",
                "password": "HxuEcx9aiAAbkwJ",
            },
            {
                "username": "picket_fence_by_mail_manager",
                "password": "SOU6x86JIpdomtK",
            },
            {
                "username": "greenhouse_queen_manager",
                "password": "1zJMmVCXjVulixf",
            },
        ]

        for my_user in my_users:
            try:
                user = User.objects.create_user(
                    username=my_user["username"], 
                    password=my_user["password"],
                    email=None
                )
                user.save()
            except:
                pass

        my_sites = [
            {
                "domain": "https://грядки-на-дачу.рф",
                "user": "beds_to_dacha_manager",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "ck_bbbab769896ead770fd9ee06dea9662456018169",
                "consumer_secret": "cs_ec90719f184673df4ddfc4763216304ee70c1241"
            },
            {
                "domain": "https://грядкипочтой.рф",
                "user": "beds_by_mail_manager",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "ck_989e16c45ebd6a461c207e73e66a9c82064f66fe",
                "consumer_secret": "cs_995774bba21d70fb39a013aa4cdceac15d9272de"
            },
            {
                "domain": "https://борисовка35.рф",
                "user": "borisovka35_manager",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "",
                "consumer_secret": ""
            },
            {
                "domain": "https://blok-konteiner35.ru",
                "user": "blok_konteiner35_manager",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "",
                "consumer_secret": ""
            },
            {
                "domain": "https://штакетникпочтой.рф",
                "user": "picket_fence_by_mail_manager",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "ck_2eaee55e9853b43245a45f2baed395facf06dea1",
                "consumer_secret": "cs_83f948c311e29a75e235315b847f6d6ea8c30815"
            },
            {
                "domain": "https://теплица-царица.рф",
                "user": "greenhouse_queen_manager",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "ck_60d6b641807616307308631244fc133c62c2da31",
                "consumer_secret": "cs_c87e8c8e48a200de655e915ab9edb7c67c590b9e"
            }
        ]
        for my_site in my_sites:
            try:
                user = User.objects.get(username=my_site["user"])
                site = Site(
                    domain=my_site["domain"],
                    user=user,
                    last_update=my_site["last_update"],
                    consumer_key=my_site["consumer_key"],
                    consumer_secret=my_site["consumer_secret"]
                )
                site.save()
            except:
                pass